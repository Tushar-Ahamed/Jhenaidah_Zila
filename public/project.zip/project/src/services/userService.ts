import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';
import { db } from '@/firebase/config';
import type {
  FirestoreUser,
  UserRole,
  UserStatus,
  CommitteeType,
  UpazilaName,
  AuditLog,
  AuditAction,
} from '@/types';

const USERS = 'users';
const AUDIT = 'audit_logs';

function now(): number {
  return Date.now();
}

// Strip hidden fields before returning to UI.
function toSafe(u: FirestoreUser) {
  const { securityKey, committeeCode, approvedBy, ...safe } = u;
  void securityKey; void committeeCode; void approvedBy;
  return safe;
}

export async function getUserDoc(uid: string): Promise<FirestoreUser | null> {
  const snap = await getDoc(doc(db, USERS, uid));
  if (!snap.exists()) return null;
  return snap.data() as FirestoreUser;
}

export async function getUserDocSafe(uid: string) {
  const u = await getUserDoc(uid);
  return u ? toSafe(u) : null;
}

export interface CreateSelfUserInput {
  uid: string;
  name: string;
  email: string;
  role: Extract<UserRole, 'student' | 'teacher' | 'alumni'>;
  upazila: UpazilaName;
}

// Self-registration: status pending, no hidden keys.
export async function createSelfUser(input: CreateSelfUserInput): Promise<void> {
  const data: FirestoreUser = {
    uid: input.uid,
    name: input.name,
    email: input.email,
    role: input.role,
    committeeType: null,
    upazila: input.upazila,
    position: null,
    status: 'pending',
    createdAt: now(),
    updatedAt: now(),
    approvedBy: null,
  };
  await setDoc(doc(db, USERS, input.uid), data);
}

export interface CreateCommitteeUserInput {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  committeeType: CommitteeType;
  upazila: UpazilaName;
  position: string;
  securityKey: string;
  committeeCode: string;
  approvedBy: string;
}

// Admin-created committee account: status active, hidden keys set.
export async function createCommitteeUser(input: CreateCommitteeUserInput): Promise<void> {
  const data: FirestoreUser = {
    uid: input.uid,
    name: input.name,
    email: input.email,
    role: input.role,
    committeeType: input.committeeType,
    upazila: input.upazila,
    position: input.position,
    status: 'active',
    createdAt: now(),
    updatedAt: now(),
    securityKey: input.securityKey,
    committeeCode: input.committeeCode,
    approvedBy: input.approvedBy,
  };
  await setDoc(doc(db, USERS, input.uid), data);
}

export interface UpdateProfileInput {
  name?: string;
  upazila?: UpazilaName;
  position?: string | null;
}

export async function updateOwnProfile(uid: string, patch: UpdateProfileInput): Promise<void> {
  await updateDoc(doc(db, USERS, uid), {
    ...patch,
    updatedAt: now(),
  });
}

export async function updateUserStatus(
  uid: string,
  status: UserStatus,
  actorId: string
): Promise<void> {
  const patch: Partial<FirestoreUser> = { status, updatedAt: now() };
  if (status === 'active') patch.approvedBy = actorId;
  await updateDoc(doc(db, USERS, uid), patch);
}

// Soft delete: mark status deleted, do not remove the document.
export async function softDeleteUser(uid: string): Promise<void> {
  await updateDoc(doc(db, USERS, uid), {
    status: 'deleted',
    updatedAt: now(),
  });
}

export async function listUsersByRole(role: UserRole): Promise<FirestoreUser[]> {
  const q = query(collection(db, USERS), where('role', '==', role));
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as FirestoreUser);
}

export async function listPendingUsers(): Promise<FirestoreUser[]> {
  const q = query(collection(db, USERS), where('status', '==', 'pending'));
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as FirestoreUser);
}

export async function listAllUsers(): Promise<FirestoreUser[]> {
  const snap = await getDocs(collection(db, USERS));
  return snap.docs.map((d) => d.data() as FirestoreUser);
}

export async function listUsersByUpazila(upazila: UpazilaName): Promise<FirestoreUser[]> {
  const q = query(collection(db, USERS), where('upazila', '==', upazila));
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as FirestoreUser);
}

// ===== Audit Logs =====

export async function writeAuditLog(entry: Omit<AuditLog, 'id' | 'createdAt'>): Promise<void> {
  await setDoc(doc(collection(db, AUDIT)), {
    ...entry,
    createdAt: serverTimestamp(),
  } as Partial<AuditLog> & { createdAt: ReturnType<typeof serverTimestamp> });
}

export async function listAuditLogs(limit = 50): Promise<AuditLog[]> {
  const snap = await getDocs(collection(db, AUDIT));
  const logs = snap.docs.map((d) => {
    const data = d.data() as AuditLog & { createdAt?: Timestamp };
    return {
      id: d.id,
      ...data,
      createdAt: data.createdAt?.toMillis?.() ?? now(),
    } as AuditLog;
  });
  return logs.sort((a, b) => b.createdAt - a.createdAt).slice(0, limit);
}

export function describeAction(action: AuditAction): string {
  const map: Record<AuditAction, string> = {
    login: 'লগইন',
    logout: 'লগআউট',
    register: 'নিবন্ধন',
    profile_update: 'প্রোফাইল হালনাগাদ',
    status_change: 'স্ট্যাটাস পরিবর্তন',
    role_change: 'ভূমিকা পরিবর্তন',
    account_created: 'অ্যাকাউন্ট তৈরি',
    account_deleted: 'অ্যাকাউন্ট মুছে ফেলা হয়েছে',
    account_approved: 'অ্যাকাউন্ট অনুমোদিত',
    password_reset: 'পাসওয়ার্ড পুনঃনির্ধারণ',
    email_verified: 'ইমেইল যাচাই',
  };
  return map[action];
}
