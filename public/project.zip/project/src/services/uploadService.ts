import {
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject,
} from 'firebase/storage';
import { storage } from '@/firebase/config';

// Upload an image to Firebase Storage and return its download URL.
// Falls back to a data URL (object URL) when Storage is unreachable so the
// UI remains functional in the demo environment.
export async function uploadImage(
  file: File,
  path: string
): Promise<{ url: string; path: string }> {
  const storageRef = ref(storage, `${path}/${Date.now()}-${file.name}`);
  try {
    const snap = await uploadBytes(storageRef, file);
    const url = await getDownloadURL(snap.ref);
    return { url, path: snap.ref.fullPath };
  } catch {
    // Fallback: local object URL (demo only — not persisted)
    const url = URL.createObjectURL(file);
    return { url, path: storageRef.fullPath };
  }
}

export async function deleteImage(path: string): Promise<void> {
  try {
    await deleteObject(ref(storage, path));
  } catch {
    // best-effort
  }
}
