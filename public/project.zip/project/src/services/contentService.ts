import {
  collection,
  doc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  addDoc,
  serverTimestamp,
  Timestamp,
  type QueryConstraint,
} from 'firebase/firestore';
import { db } from '@/firebase/config';
import { NOTICES, EVENTS, GALLERY } from '@/data/sampleData';
import type { Notice, OrgEvent, GalleryItem, UpazilaName } from '@/types';

function tsToMillis(t?: Timestamp | { toDate: () => Date }): number {
  if (!t) return Date.now();
  if (t instanceof Timestamp) return t.toMillis();
  if (typeof (t as Timestamp).toDate === 'function') return (t as Timestamp).toDate().getTime();
  return Date.now();
}

type FirestoreDoc = Record<string, unknown> & { date?: string | Timestamp | { toDate: () => Date } };

function normalizeNotice(d: FirestoreDoc): Notice {
  const date = typeof d.date === 'string' ? d.date : new Date(tsToMillis(d.date)).toISOString();
  return { ...(d as Omit<Notice, 'date'>), date };
}
function normalizeEvent(d: FirestoreDoc): OrgEvent {
  const date = typeof d.date === 'string' ? d.date : new Date(tsToMillis(d.date)).toISOString();
  return { ...(d as Omit<OrgEvent, 'date'>), date };
}
function normalizeGallery(d: FirestoreDoc): GalleryItem {
  const date = typeof d.date === 'string' ? d.date : new Date(tsToMillis(d.date)).toISOString();
  return { ...(d as Omit<GalleryItem, 'date'>), date };
}

// ===== Notices =====
export async function listNotices(scope?: 'district' | 'upazila', upazila?: UpazilaName): Promise<Notice[]> {
  try {
    const constraints: QueryConstraint[] = [orderBy('date', 'desc')];
    if (scope) constraints.push(where('scope', '==', scope));
    if (upazila) constraints.push(where('upazila', '==', upazila));
    const snap = await getDocs(query(collection(db, 'notices'), ...constraints));
    if (snap.empty) {
      return scope === 'upazila' && upazila
        ? NOTICES.filter((n) => n.scope === 'upazila' && n.upazila === upazila)
        : NOTICES;
    }
    return snap.docs.map((d) => normalizeNotice(d.data()));
  } catch {
    return scope === 'upazila' && upazila
      ? NOTICES.filter((n) => n.scope === 'upazila' && n.upazila === upazila)
      : NOTICES;
  }
}

export interface NoticeInput {
  title: string;
  body: string;
  category: Notice['category'];
  date: string;
  pinned?: boolean;
  scope: 'district' | 'upazila';
  upazila?: UpazilaName;
  authorId: string;
}

export async function createNotice(input: NoticeInput): Promise<string> {
  try {
    const ref = await addDoc(collection(db, 'notices'), { ...input, createdAt: serverTimestamp() });
    return ref.id;
  } catch {
    return `local-${Date.now()}`;
  }
}

export async function updateNotice(id: string, patch: Partial<NoticeInput>): Promise<void> {
  try {
    await updateDoc(doc(db, 'notices', id), patch);
  } catch {
    // demo fallback
  }
}

export async function deleteNotice(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'notices', id));
  } catch {
    // demo fallback
  }
}

// ===== Events =====
export async function listEvents(scope?: 'district' | 'upazila', upazila?: UpazilaName): Promise<OrgEvent[]> {
  try {
    const constraints: QueryConstraint[] = [orderBy('date', 'desc')];
    if (scope) constraints.push(where('scope', '==', scope));
    if (upazila) constraints.push(where('upazila', '==', upazila));
    const snap = await getDocs(query(collection(db, 'events'), ...constraints));
    if (snap.empty) {
      return scope === 'upazila' && upazila
        ? EVENTS.filter((e) => e.scope === 'upazila' && e.upazila === upazila)
        : EVENTS;
    }
    return snap.docs.map((d) => normalizeEvent(d.data()));
  } catch {
    return scope === 'upazila' && upazila
      ? EVENTS.filter((e) => e.scope === 'upazila' && e.upazila === upazila)
      : EVENTS;
  }
}

export interface EventInput {
  title: string;
  description: string;
  date: string;
  location: string;
  coverImage?: string;
  status: OrgEvent['status'];
  scope: 'district' | 'upazila';
  upazila?: UpazilaName;
  authorId: string;
}

export async function createEvent(input: EventInput): Promise<string> {
  try {
    const ref = await addDoc(collection(db, 'events'), { ...input, createdAt: serverTimestamp() });
    return ref.id;
  } catch {
    return `local-${Date.now()}`;
  }
}

export async function updateEvent(id: string, patch: Partial<EventInput>): Promise<void> {
  try {
    await updateDoc(doc(db, 'events', id), patch);
  } catch {
    // demo fallback
  }
}

export async function deleteEvent(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'events', id));
  } catch {
    // demo fallback
  }
}

// ===== Gallery =====
export async function listGallery(scope?: 'district' | 'upazila', upazila?: UpazilaName): Promise<GalleryItem[]> {
  try {
    const constraints: QueryConstraint[] = [orderBy('date', 'desc')];
    if (scope) constraints.push(where('scope', '==', scope));
    if (upazila) constraints.push(where('upazila', '==', upazila));
    const snap = await getDocs(query(collection(db, 'gallery'), ...constraints));
    if (snap.empty) {
      return scope === 'upazila' && upazila
        ? GALLERY.filter((g) => g.scope === 'upazila' && g.upazila === upazila)
        : GALLERY;
    }
    return snap.docs.map((d) => normalizeGallery(d.data()));
  } catch {
    return scope === 'upazila' && upazila
      ? GALLERY.filter((g) => g.scope === 'upazila' && g.upazila === upazila)
      : GALLERY;
  }
}

export interface GalleryInput {
  title: string;
  url: string;
  category: string;
  date: string;
  scope: 'district' | 'upazila';
  upazila?: UpazilaName;
  authorId: string;
}

export async function createGalleryItem(input: GalleryInput): Promise<string> {
  try {
    const ref = await addDoc(collection(db, 'gallery'), { ...input, createdAt: serverTimestamp() });
    return ref.id;
  } catch {
    return `local-${Date.now()}`;
  }
}

export async function updateGalleryItem(id: string, patch: Partial<GalleryInput>): Promise<void> {
  try {
    await updateDoc(doc(db, 'gallery', id), patch);
  } catch {
    // demo fallback
  }
}

export async function deleteGalleryItem(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'gallery', id));
  } catch {
    // demo fallback
  }
}
