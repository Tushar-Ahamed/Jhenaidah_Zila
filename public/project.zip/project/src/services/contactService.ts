import {
  collection,
  addDoc,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from '@/firebase/config';
import type { ContactMessage } from '@/types';

export async function submitContactMessage(msg: Omit<ContactMessage, 'id' | 'createdAt'>): Promise<void> {
  await addDoc(collection(db, 'contact_messages'), {
    ...msg,
    createdAt: serverTimestamp(),
  });
}
