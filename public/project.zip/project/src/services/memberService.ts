import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  type QueryDocumentSnapshot,
} from 'firebase/firestore';
import { db } from '@/firebase/config';
import type { MemberProfile, MemberStatus, UpazilaName } from '@/types';
import { MEMBERS } from '@/data/membersData';

const COL = 'members';

function now(): number {
  return Date.now();
}

// Seed sample members into Firestore if the collection is empty (first run).
export async function seedMembersIfEmpty(): Promise<void> {
  try {
    const snap = await getDocs(collection(db, COL));
    if (!snap.empty) return;
    await Promise.all(
      MEMBERS.map((m) => setDoc(doc(db, COL, m.id), m))
    );
  } catch {
    // Firestore unreachable in demo — fall back to local data.
  }
}

export async function getMember(id: string): Promise<MemberProfile | null> {
  try {
    const snap = await getDoc(doc(db, COL, id));
    if (!snap.exists()) return MEMBERS.find((m) => m.id === id) ?? null;
    return snap.data() as MemberProfile;
  } catch {
    return MEMBERS.find((m) => m.id === id) ?? null;
  }
}

export async function listMembers(status?: MemberStatus): Promise<MemberProfile[]> {
  try {
    const q = status
      ? query(collection(db, COL), where('status', '==', status), orderBy('createdAt', 'desc'))
      : query(collection(db, COL), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    if (snap.empty) {
      return status ? MEMBERS.filter((m) => m.status === status) : MEMBERS;
    }
    return snap.docs.map((d) => d.data() as MemberProfile);
  } catch {
    return status ? MEMBERS.filter((m) => m.status === status) : MEMBERS;
  }
}

export async function listApprovedMembers(): Promise<MemberProfile[]> {
  return listMembers('approved');
}

export async function listPendingMembers(): Promise<MemberProfile[]> {
  return listMembers('pending');
}

export async function listRejectedMembers(): Promise<MemberProfile[]> {
  return listMembers('rejected');
}

// Paginated fetch — returns items + the last doc cursor for the next page.
export interface PagedResult {
  items: MemberProfile[];
  cursor: QueryDocumentSnapshot | null;
  hasMore: boolean;
}

export async function listMembersPaged(
  pageSize: number,
  cursor: QueryDocumentSnapshot | null
): Promise<PagedResult> {
  try {
    const base = query(collection(db, COL), where('status', '==', 'approved'), orderBy('createdAt', 'desc'));
    const q = cursor ? query(base, startAfter(cursor), limit(pageSize)) : query(base, limit(pageSize));
    const snap = await getDocs(q);
    const items = snap.docs.map((d) => d.data() as MemberProfile);
    const last = snap.docs[snap.docs.length - 1] ?? null;
    return { items, cursor: last, hasMore: snap.size === pageSize };
  } catch {
    return { items: MEMBERS.filter((m) => m.status === 'approved'), cursor: null, hasMore: false };
  }
}

export interface CreateMemberInput {
  id: string;
  name: string;
  photo: string;
  department: string;
  session: string;
  hall: string;
  upazila: UpazilaName;
  phone: string;
  email: string;
  bloodGroup: MemberProfile['bloodGroup'];
  facebook?: string;
  linkedin?: string;
  bio: string;
}

export async function createMember(input: CreateMemberInput): Promise<void> {
  const data: MemberProfile = {
    ...input,
    status: 'pending',
    createdAt: now(),
    updatedAt: now(),
  };
  try {
    await setDoc(doc(db, COL, input.id), data);
  } catch {
    // demo fallback
  }
}

export interface UpdateMemberInput {
  name?: string;
  photo?: string;
  department?: string;
  session?: string;
  hall?: string;
  upazila?: UpazilaName;
  phone?: string;
  email?: string;
  bloodGroup?: MemberProfile['bloodGroup'];
  facebook?: string;
  linkedin?: string;
  bio?: string;
}

export async function updateMember(id: string, patch: UpdateMemberInput): Promise<void> {
  try {
    await updateDoc(doc(db, COL, id), { ...patch, updatedAt: now() });
  } catch {
    // demo fallback
  }
}

export async function setMemberStatus(id: string, status: MemberStatus): Promise<void> {
  try {
    await updateDoc(doc(db, COL, id), { status, updatedAt: now() });
  } catch {
    // demo fallback
  }
}

export async function approveMember(id: string): Promise<void> {
  await setMemberStatus(id, 'approved');
}

export async function rejectMember(id: string): Promise<void> {
  await setMemberStatus(id, 'rejected');
}

// Client-side filtering helpers (used with the in-memory fallback too).
export interface MemberFilters {
  query?: string;
  department?: string;
  session?: string;
  upazila?: UpazilaName | 'all';
  bloodGroup?: MemberProfile['bloodGroup'] | 'all';
}

export function filterMembers(members: MemberProfile[], f: MemberFilters): MemberProfile[] {
  const q = (f.query ?? '').trim().toLowerCase();
  return members.filter((m) => {
    if (m.status !== 'approved') return false;
    if (q && !(`${m.name} ${m.email} ${m.department} ${m.upazila ?? ''}`.toLowerCase().includes(q))) return false;
    if (f.department && f.department !== 'all' && m.department !== f.department) return false;
    if (f.session && f.session !== 'all' && m.session !== f.session) return false;
    if (f.upazila && f.upazila !== 'all' && m.upazila !== f.upazila) return false;
    if (f.bloodGroup && f.bloodGroup !== 'all' && m.bloodGroup !== f.bloodGroup) return false;
    return true;
  });
}

export function paginate<T>(items: T[], page: number, pageSize: number): T[] {
  const start = (page - 1) * pageSize;
  return items.slice(start, start + pageSize);
}

export function totalPages(total: number, pageSize: number): number {
  return Math.max(1, Math.ceil(total / pageSize));
}
