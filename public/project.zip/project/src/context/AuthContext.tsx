import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as fbSignOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  updateProfile,
  reload,
  type User,
} from 'firebase/auth';
import { auth, applyAuthPersistence, type PersistenceMode } from '@/firebase/config';
import { getUserDoc, createSelfUser, writeAuditLog } from '@/services/userService';
import type { AppUser, FirestoreUser, UserRole, UpazilaName } from '@/types';

export type AuthErrorCode =
  | 'EMAIL_NOT_VERIFIED'
  | 'ACCOUNT_PENDING'
  | 'ACCOUNT_SUSPENDED'
  | 'ACCOUNT_DELETED'
  | 'NO_USER_DOC'
  | 'NOT_ALLOWED'
  | 'AUTH_FAILED';

export class AuthError extends Error {
  code: AuthErrorCode;
  constructor(code: AuthErrorCode, message: string) {
    super(message);
    this.code = code;
    this.name = 'AuthError';
  }
}

interface RegisterInput {
  name: string;
  email: string;
  password: string;
  role: Extract<UserRole, 'student' | 'teacher' | 'alumni'>;
  upazila: UpazilaName;
}

interface LoginInput {
  email: string;
  password: string;
  remember: boolean;
}

interface AuthContextValue {
  user: AppUser | null;
  firestoreUser: FirestoreUser | null;
  loading: boolean;
  login: (input: LoginInput) => Promise<void>;
  register: (input: RegisterInput) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  resendVerification: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

function toAppUser(u: User, fs: FirestoreUser): AppUser {
  return {
    uid: u.uid,
    email: u.email,
    displayName: u.displayName ?? fs.name,
    photoURL: u.photoURL,
    role: fs.role,
    status: fs.status,
    upazila: fs.upazila,
    position: fs.position,
    committeeType: fs.committeeType,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [firestoreUser, setFirestoreUser] = useState<FirestoreUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (!u) {
        setUser(null);
        setFirestoreUser(null);
        setLoading(false);
        return;
      }
      try {
        const fs = await getUserDoc(u.uid);
        if (!fs) {
          setUser(null);
          setFirestoreUser(null);
        } else {
          setFirestoreUser(fs);
          setUser(toAppUser(u, fs));
        }
      } catch {
        setUser(null);
        setFirestoreUser(null);
      } finally {
        setLoading(false);
      }
    });
    return unsub;
  }, []);

  const login = async (input: LoginInput) => {
    const mode: PersistenceMode = input.remember ? 'local' : 'session';
    await applyAuthPersistence(mode);

    const cred = await signInWithEmailAndPassword(auth, input.email, input.password);
    const u = cred.user;

    // Email verification required for self-registered accounts.
    if (!u.emailVerified) {
      await fbSignOut(auth);
      throw new AuthError('EMAIL_NOT_VERIFIED', 'আপনার ইমেইল যাচাই হয়নি। ইনবক্স চেক করুন।');
    }

    // After Firebase login, check Firestore user document. Never trust frontend role.
    const fs = await getUserDoc(u.uid);
    if (!fs) {
      await fbSignOut(auth);
      throw new AuthError('NO_USER_DOC', 'ব্যবহারকারীর তথ্য পাওয়া যায়নি।');
    }

    if (fs.status === 'pending') {
      await fbSignOut(auth);
      throw new AuthError('ACCOUNT_PENDING', 'আপনার অ্যাকাউন্ট এখনো অনুমোদিত হয়নি।');
    }
    if (fs.status === 'suspended') {
      await fbSignOut(auth);
      throw new AuthError('ACCOUNT_SUSPENDED', 'আপনার অ্যাকাউন্ট স্থগিত করা হয়েছে।');
    }
    if (fs.status === 'deleted') {
      await fbSignOut(auth);
      throw new AuthError('ACCOUNT_DELETED', 'এই অ্যাকাউন্টটি মুছে ফেলা হয়েছে।');
    }

    setFirestoreUser(fs);
    setUser(toAppUser(u, fs));

    await writeAuditLog({
      actorId: u.uid,
      actorEmail: u.email ?? '',
      actorRole: fs.role,
      action: 'login',
      details: 'সফল লগইন',
    });
  };

  const register = async (input: RegisterInput) => {
    // Self-register only for student/teacher/alumni.
    if (!['student', 'teacher', 'alumni'].includes(input.role)) {
      throw new AuthError('NOT_ALLOWED', 'এই ভূমিকার জন্য স্ব-নিবন্ধন অনুমোদিত নয়।');
    }

    await applyAuthPersistence('local');
    const cred = await createUserWithEmailAndPassword(auth, input.email, input.password);
    const u = cred.user;

    await updateProfile(u, { displayName: input.name });
    await createSelfUser({
      uid: u.uid,
      name: input.name,
      email: input.email,
      role: input.role,
      upazila: input.upazila,
    });

    await sendEmailVerification(u);

    await writeAuditLog({
      actorId: u.uid,
      actorEmail: u.email ?? '',
      actorRole: input.role,
      action: 'register',
      details: `স্ব-নিবন্ধন: ${input.name}`,
    });

    await fbSignOut(auth);
  };

  const logout = async () => {
    if (user) {
      try {
        await writeAuditLog({
          actorId: user.uid,
          actorEmail: user.email ?? '',
          actorRole: user.role,
          action: 'logout',
          details: 'লগআউট',
        });
      } catch {
        // best-effort
      }
    }
    await fbSignOut(auth);
    setUser(null);
    setFirestoreUser(null);
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  const resendVerification = async () => {
    if (auth.currentUser) {
      await sendEmailVerification(auth.currentUser);
    }
  };

  const refreshUser = async () => {
    if (auth.currentUser) {
      await reload(auth.currentUser);
      const fs = await getUserDoc(auth.currentUser.uid);
      if (fs) {
        setFirestoreUser(fs);
        setUser(toAppUser(auth.currentUser, fs));
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{ user, firestoreUser, loading, login, register, logout, resetPassword, resendVerification, refreshUser }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
